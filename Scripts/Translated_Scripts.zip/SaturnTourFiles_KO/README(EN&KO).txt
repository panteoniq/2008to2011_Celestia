*************************************************************************************
*                                                                                   *
*                   SaturnTour.cel V1.05 - Last Revision 5-9-04                     *
*                                                                                   *
* Revised on 16 Apr 04: Made changes to README.txt, and added path information to   *
*                       the zip file.                                               *
* Revised on  9 May 04: Corrected a bug with cloudmaps.                             *
*                                                                                   *
* This script requires that you have the ring_locs.ssc and the satmoons2.ssc files  *
* installed in your Program Files\Celestia\extras directory. These files have been  *
* included in this package for your convenience. Simply unzip the SaturnTour.cel    *
* file into your main Celestia directory, and unzip satmoons2.ssc and ring_locs.ssc *
* into your extras directory. Please note that satmoons2.ssc has been modified in   *
* order to correct the location of the Latium Chasma on Dione.                      *
*                                                                                   *
* NOTE: If you don't wish to see *all* of Saturn's locations displayed              *
*       while running this script, select "Render" from Celestia's menu             *
*       taskbar. Then select "Locations" and uncheck the "Label Features"           *
*       box. Right now, there's no way to do this from within a script.             *        
*       If you like, you can also press SHIFT and "&" to do the same                *
*       thing.                                                                      *
*                                                                                   *
*       This script was written for use with Celestia V1.3.2 Pre1 or later.         *
*                                                                                   *
* Further information: I have also included revised texture maps for Tethys and     *
* Mimas, as well as new textures for Saturn and its rings.                          *
* Please understand that MY images are limited to a paltry 1024x1024 resolution     *
* because of the limited graphics capabilities of my computer hardware. If you need *
* larger image maps, please visit the sites referenced under the Credits Heading    *
* below.                                                                            *
*                                                                                   *
* To perform the installation of these files, simply follow the instructions below. *
*                                                                                   *
* 1. First, simply unzip the Tethysc.jpg, Mimasc.jpg, Saturn.jpg, and               *
*    SaturnRings.png files into the directory shown                                 *
*    here: Program Files\Celestia\textures\medres                                   *
* 2. Next, modify your solarsys.ssc file in order to make use of the new            *
*    textures. Simply use Notepad (or it's equivalent) to modify your               *
*    solarsys.ssc file (Located in the Program Files\Celestia\data directory) as    *
*    follows:                                                                       *
*                                                                                   *
*    A. Under the "Saturn" "Sol" heading: Change the texture definition to          *
*       read: Texture - "Saturn.jpg" - Note the capital 'S'                         *
*                                                                                   *
*    B. Under the "Tethys" "Sol/Saturn" heading: Change the texture definition      *
*       to read: Texture - "Tethysc.jpg"                                            *
*                                                                                   *
*    C. Under the "Mimas" "Sol/Saturn" heading: Change the texture definition       *
*       to read: Texture - "Mimasc.jpg"                                             *
*                                                                                   *
*    NOTE: If you'd rather bypass steps 2A-2C above, you can simply copy the file   *
*          SaturnTour.ssc (Also included in this package) into your                 *
*          Program Files\Celestia\extras directory. This SSC file simply redefines  *
*          the textures which will be used to display the surfaces of the Saturnian *
*          planetary objects which are referenced by the SaturnTour script.         *
*          Please be aware that if you choose to retain your current textures and   *            *          you wish to see the NEW textures while visiting Saturn, you'll have to   *
*          right-click on Saturn while it's being displayed, then you'll have to    *
*          to select the "SaturnTour" option in order to display the textures I've  *
*          included in this package. If you like, this can be done prior to         *
*          running the script, or you can do it while the script is displaying      *
*          Saturn on the screen. Just MY preference, but I'd simply change the      *
*          solarsys.ssc file as described in steps 2A-2C to use the new textures    *
*          ALL of the time.                                                         *
*                                                                                   *
* 3. If you wish to use the new Saturn Rings texture, there's one more step.        *
*                                                                                   *
*    A. Again, Under the "Saturn" "Sol" heading - find and replace the rings        *
*       definition with the following lines:                                        *
*                                                                                   *
*               Rings {                                                             *
*               Inner   74660                                                       *
*               Outer  140220                                                       *
*               Texture "SaturnRings.png"                                           *
*               Color  [ 1.0 0.88 0.82 ]                                            *
*                     }                                                             *
*                                                                                   *
* 4. Note: The Tethys and Mimas textures have been modified to display these moons  *
*    in what I believe to be are more accurate colors. Since we really don't have   *
*    great accurate colored pictures of these moons yet, I simply tried to make an  *
*    educated guess as to what the colors should be. If you don't like the revised  *
*    textures, then don't use them!                                                 *
*                                                                                   * 
* 5. Please note also that this is the FULL Saturn Tour package. If you simply wish *
*    to obtain the script and revised SSC files, that package can also be found on  *
*    my website                                                                     *
*                                                                                   *
*    That's all for now, Take care, and Enjoy! - Bob                                *
*                                                                                   *
* Credits: ________________________________________________________________________ *
*                                                                                   *
* Mimasc.jpg     - Author: Original USGS map revised by Grant Hutchison.            *
*                  Revisions: Bob Hegwood - Recolored.                              *
* ring_locs.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
* satmoons2.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
*                  Revisions: Bob Hegwood - Corrected location of Latium Chasma     *
*                                           with blessings from Jennifer Blue at    *
*                                           USGS and Grant Hutchison.               *
* Saturn.jpg     - Author: Bjorn Jonnson                                            *
*                  Website: http://www.mmedia.is/~bjj/                              *
*                  Revisions: Bob Hegwood - Resized to 1024 x 512.                  *
* SaturnRings.png- Author:  Jens (Jim) Meyer                                        *
*                  Website: http://home.arcor.de/jimpage                            *
*                  Revisions: Bob Hegwood - Resized to 1024 x 2.                    *
* SaturnTour.ssc - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
* SaturnTour.cel - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
* Tethysc.jpg    - Author: Original USGS map revised by Grant Hutchison.            *
*                  Revisions: Bob Hegwood - Recolored.                              *
*                                                                                   *
*          ________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Questions or comments? Send them to me at the following email address:            *
*                                                                                   *
* bobhegwood@earthlink.net                                                          *
*                                                                                   *
* Visit my Celestia web page at: http://home.earthlink.net/~bobhegwood              *
*                                                                                   *
*************************************************************************************



-

���� ���� ��ũ��Ʈ ������ : Bob Hegwood

���� �� �ѱ�ȭ : fly_space (In Celestia Forum)



1) ������ ���� ���ɼ��� �ֽ��ϴ�. ���� Ȯ�� �� 0.2�� ������ �� ��ġ���� �ϰڽ��ϴ�.

2) planatia�� �浹 ��ȭ���� �ƴ϶� ����� ��Ī�ϴ� �ܾ��Դϴ�. Venustour ��ũ��Ʈ ���� ���߿� ���� �����̾����ϴ�. ȥ�������� �� �˼��մϴ�.

3) ��ũ��Ʈ �����̳� ���� ����, ��Ÿ, ����� Ʋ�� ���� http://blog.naver.com/wjdeogks18�� ���� �˷��ֽñ� �ٶ��ϴ�.


4) ������Ƽ�� �ٿ�ε� �ּ� : www.shatters.net/celestia/download

5) ������Ƽ�� ���� �ּ� : www.shatters.net/forum

6) ������Ƽ�� �ֵ�� Ȩ������ �ּ� : www.celestiamotherlode.net

7) ������Ƽ�� ���� ������ֽð�, ���� �˷��ּ���.


8) Readme�� 0.2�� 0.3 �� �����ϰڽ��ϴ�.